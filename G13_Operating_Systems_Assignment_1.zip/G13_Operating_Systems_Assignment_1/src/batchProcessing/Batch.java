package batchProcessing;

import java.util.HashMap;

public class Batch {

	static HashMap<String, Command> lookup = new HashMap<>();
	

}
